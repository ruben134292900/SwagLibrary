local oldmath = math
local math2 = {}
function math2.interpolator(Num1, Num2)
	return function(T)
		return Num1 + (Num2 - Num1) * T
	end
end

function math2.clamp(n, min, max)
	if n >= max then
		return max
	elseif n <= min then
		return min
	else
		return n
	end
end

function math2.lerp(Current, Target, T)
	return Current + (Target - Current) * T
end

function math2.rounddec(num, dec)
	local mult = 10 ^ dec
	return math.floor(num * mult) / mult
end

function math2.percent(n, min, max)
	local min = min or 0
	local max = max or 100

	return ((min + n) / max) * 100
end

function math2.random2(min, max)
	return math.random(min * 1000, max * 1000) / 1000
end

math2.euler = 2.718281828459045

math = setmetatable(math2, { __index = oldmath })
