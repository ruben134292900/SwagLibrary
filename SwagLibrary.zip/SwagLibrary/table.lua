table = setmetatable({}, { __index = table })

function table.freeze(t)
    t = setmetatable(t, {
        __frozen = true,
        __newindex = function(t)
            error(t .. " is frozen")
        end
    })
    return t
end

function table.unfreeze(t)
    t = setmetatable(t, {
        __frozen = nil,
        __newindex = function(t, k, v)
            t[k] = v
        end
    })
    return t
end

function table.isfrozen(t)
    if getmetatable(t).__frozen == true then
        return true
    else
        return false
    end
end

function table.copy(t)
    local copied = {}
    for i, v in next, t do
        if type(v) == "table" then
            copied[i] = table.copy(v)
        else
            copied[i] = v
        end
    end
    return copied
end

function table.deepfreeze(t)
    for i, v in next, t do
        if type(v) == "table" then
            pcall(function() table.freeze(v) end)
            table.deepfreeze(v)
        end
    end
    pcall(function() table.freeze(t) end)
    return t
end

function table.isdeepfrozen(t)
    local deepfrozen = table.isfrozen(t)
    for i, v in next, t do
        if type(v) == "table" then
            deepfrozen = deepfrozen and table.isdeepfrozen(v)
        end
    end
    return deepfrozen
end

function table.destroy(t)
    for i, v in next, t do
        if type(v) == "table" then
            table.destroy(v)
        end
        table.clear(v)
    end
end

function table.replace(t, vt)
    for i, v in next, vt do
        if t[i] then
            t[i] = v
        end
    end
end

function table.deepreplace(t, vt)
    for i, v in next, vt do
        if t[i] then
            if type(t[i]) == "table" and type(v) == "table" then
                table.deepreplace(t[i], v)
            else
                t[i] = v
            end
        end
    end
end

function table.find(t, value)
    local key = 0
    for i, v in next, t do
        key = key + 1
        if v == value then
            break
        end
    end
    return key
end