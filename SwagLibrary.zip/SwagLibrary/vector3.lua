Vector3 = {}

#include "./SwagLibrary/math.lua"

function Vector3.tostring(Vector)
    return "{ " .. Vector.X .. ", " .. Vector.Y .. ", " .. Vector.Z .. " }"
end

local function getMagnitude(Vector)
    local X, Y, Z = Vector:Components()
    return math.sqrt(X * X + Y * Y + Z * Z)
end

local function GetUnit(Vector)
    local Magnitude = getMagnitude(Vector)
    return Vector / Magnitude
end

local vectorMeta = {
    __name = "Vector",
    __add = function(a, b)
        local aType = type(a)
        local bType = type(b)
        if aType == "table" and bType == "table" then
            return Vector3.new(a.X + b.X, a.Y + b.Y, a.Z + b.Z)
        elseif aType == "table" and bType == "number" then
            return Vector3.new(a.X + b, a.Y + b, a.Z + b)
        elseif aType == "number" and bType == "table" then
            return Vector3.new(b.X + a, b.Y + a, b.Z + a)
        end
    end,
    __sub = function(a, b)
        local aType = type(a)
        local bType = type(b)
        if aType == "table" and bType == "table" then
            return Vector3.new(a.X - b.X, a.Y - b.Y, a.Z - b.Z)
        elseif aType == "table" and bType == "number" then
            return Vector3.new(a.X - b, a.Y - b, a.Z - b)
        elseif aType == "number" and bType == "table" then
            return Vector3.new(b.X - a, b.Y - a, b.Z - a)
        end
    end,
    __div = function(a, b)
        local aType = type(a)
        local bType = type(b)
        if aType == "table" and bType == "table" then
            return Vector3.new(a.X / b.X, a.Y / b.Y, a.Z / b.Z)
        elseif aType == "table" and bType == "number" then
            return Vector3.new(a.X / b, a.Y / b, a.Z / b)
        elseif aType == "number" and bType == "table" then
            return Vector3.new(b.X / a, b.Y / a, b.Z / a)
        end
    end,
    __unm = function(self)
        return Vector3.new(-self.X, -self.Y, -self.Z)
    end,
    __mul = function(a, b)
        local aType = type(a)
        local bType = type(b)
        if aType == "table" and bType == "table" then
            return Vector3.new(a.X * b.X, a.Y * b.Y, a.Z * b.Z)
        elseif aType == "table" and bType == "number" then
            return Vector3.new(a.X * b, a.Y * b, a.Z * b)
        elseif aType == "number" and bType == "table" then
            return Vector3.new(b.X * a, b.Y * a, b.Z * a)
        end
    end,
    __pow = function(a, b)
        local aType = type(a)
        local bType = type(b)
        if aType == "table" and bType == "table" then
            return Vector3.new(a.X ^ b.X, a.Y ^ b.Y, a.Z ^ b.Z)
        elseif aType == "table" and bType == "number" then
            return Vector3.new(a.X ^ b, a.Y ^ b, a.Z ^ b)
        elseif aType == "number" and bType == "table" then
            return Vector3.new(b.X ^ a, b.Y ^ a, b.Z ^ a)
        end
    end,
    __call = function (self)
        print(Vector3.tostring(self))
    end,
    __tostring = function(self)
        return Vector3.tostring(self)
    end,

    __index = function(self, key)
        --if self[key] then
            if key == "magnitude" or key == "Magnitude" then
                return getMagnitude(self)
            elseif key == "Unit" or key == "unit" then
                return GetUnit(self)
            end
       -- end
    end,

    __metatable = "Vector3",
}



function Vector3.new(X, Y, Z)
    local Vector = {
        X = X or 0,
        Y = Y or 0,
        Z = Z or 0,
        --magnitude = 0,
       -- Magnitude = 0,
    }

    setmetatable(Vector, vectorMeta)

    Vector.Components = function(self)
        return Vector.X, Vector.Y, Vector.Z
    end
    Vector.ToTDV = function(self)
        return Vec(Vector.X, Vector.Y, Vector.Z)
    end

    return Vector
end

function Vector3.fromTDV(vec)
    return Vector3.new(vec[1], vec[2], vec[3])
end

function Vector3.random(min, max)
    if (type(min) and type(max)) == "table" then
        return Vector3.new(math.random2(min.X, max.X), math.random2(min.Y, max.Y), math.random2(min.Z, max.Z))
    else
        return Vector3.zero
    end
end

function Vector3.clamp(vector, min, max)
    return Vector3.new(
        math.clamp(vector.X, (type(min) == "table" and min.X or min), (type(max) == "table" and max.X or max)),
        math.clamp(vector.Y, (type(min) == "table" and min.Y or min), (type(max) == "table" and max.Y or max)),
        math.clamp(vector.Z, (type(min) == "table" and min.Z or min), (type(max) == "table" and max.Z or max))
    )
end

function Vector3.abs(vector)
    return Vector3.new(math.abs(vector.X), math.abs(vector.Y), math.abs(vector.Z))
end

Vector3.zero = Vector3.new()
Vector3.one = Vector3.new(1, 1, 1)

Vector3 = setmetatable(Vector3, {
    __index = function(self, key)
        if self[key] then
            if key == "zero" then
                return Vector3.new()
            elseif key == "one" then
                return Vector3.new(1, 1, 1)
            else
                return self[key]
            end
        end
    end,
})